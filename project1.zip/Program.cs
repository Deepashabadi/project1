﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_1
{
    class Program
    {
        static void display(int[] a, int n)
        {
            int i = 0;
            int[,]b = new int[n, n];
            for (int y = 0; y < n; y++)
            {
                for (int x = 0; x < n; x++)
                {
                    b[y, x] = a[i];
                    i++;
                    Console.Write(b[y, x] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine(" ");
        }
        
        static void Main(string[] args) { 
            Console.Write("Enter the value of n = ");
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[n * n ];
            for (int i = 0; i < n; i++)
            {
                a[i] = 0;
                a[a.Length - 2] = 1;
            }
                display( a , n);
            
            while (true)
            {
                
                int k, temp = 0, pos;
                Console.WriteLine("2 = Down ,8 = Up , 6 = Right  ,4 = Left");
                Console.WriteLine("Enter the key");
                int key = int.Parse(Console.ReadLine());

                if (key == 2 || key == 4 || key == 6 || key == 8)
                {
                    if (key == 6)
                    {
                        pos = Array.IndexOf(a, 1);
                        if ((pos + 1) % n == 0)
                        {
                            Console.WriteLine("Can't shift right");
                            display(a, n);
                        }
                        else
                        {


                            k = pos;

                            temp = a[k];
                            a[k] = a[k + 1];
                            a[k + 1] = temp;
                            display(a, n);
                        }
                        
                        

                        
                    }





                    else if (key == 2)
                    {
                        pos = Array.IndexOf(a, 1);
                        if ((pos >= a.Length - n) && pos < a.Length)
                        {
                            Console.WriteLine("Can't shift down ");
                            display(a, n);
                        }
                        else
                        {
                            k = pos;
                            temp = a[k];
                            a[k] = a[k + n];
                            a[k + n] = temp;
                            display(a, n);
                        }



                       
                    }

                    else if (key == 4)
                    {
                        pos = Array.IndexOf(a, 1);
                        if (pos % n == 0)
                        {
                            Console.WriteLine("Can't shift left");
                            display(a, n);
                        }
                        else
                        {
                            k = pos;
                            temp = a[k];
                            a[k] = a[k - 1];
                            a[k - 1] = temp;
                            display(a, n);
                        }

                    }
                    else if (key == 8)
                    {
                        pos = Array.IndexOf(a, 1);
                        if ((pos >= 0) && (pos < n))
                        {
                            Console.WriteLine("Can't shift up");
                            display(a, n);
                        }
                        else
                        {
                            k = pos;
                            temp = a[k];
                            a[k] = a[k - n];
                            a[k - n] = temp;
                            display(a, n);
                        }
                    }
                    }
                else
                {
                    Console.WriteLine("invalid key");
                }
                
              
                }
            }
            
        }
    }

       

        
        
     
            
    
